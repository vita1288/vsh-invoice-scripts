// Membaca screenshot bukti transfer (bank, e-wallet, QRIS) → data pembayaran terstruktur.
// Pendekatan generik: deteksi metode dari kata kunci, lalu cari nilai berdasarkan label umum
// (pada baris yang sama atau baris berikutnya). Hasil selalu dikonfirmasi di CLI.
const path = require('path');
const { createWorker } = require('tesseract.js');

const LANG_PATH = path.join(
  path.dirname(require.resolve('@tesseract.js-data/eng/package.json')),
  '4.0.0_best_int'
);

async function readText(imagePath) {
  const worker = await createWorker('eng', 1, { langPath: LANG_PATH, gzip: true });
  try {
    const { data } = await worker.recognize(imagePath);
    return data.text;
  } finally {
    await worker.terminate();
  }
}

// ---- Metode pembayaran (urutan = prioritas; yang lebih spesifik di atas) ----
const METHODS = [
  ['ShopeePay', /shopee\s*pay/i],
  ['GoPay', /go\s*pay|gojek/i],
  ['OVO', /\bovo\b/i],
  ['DANA', /(?<!sumber\s)(?<!sumber\s\s)\bdana\b(?!\s*(ditransfer|masuk))/i],
  ['LinkAja', /link\s*aja/i],
  ['SeaBank', /sea\s*bank/i],
  ['Bank Jago', /\bjago\b/i],
  ['BCA', /\bbca\b|m-?bca|m-transfer|klik\s*bca|mybca/i],
  ['BRI', /\bbri\b|brimo/i],
  ['BNI', /\bbni\b|wondr/i],
  ['Mandiri', /mandiri|livin/i],
  ['BSI', /\bbsi\b|syariah\s+indonesia/i],
  ['CIMB Niaga', /cimb|octo/i],
  ['Permata', /permata/i],
  ['blu by BCA Digital', /\bblu\b/i],
  ['Jenius', /jenius|\bbtpn\b/i],
  ['QRIS', /\bqris\b/i],
];

// Untuk struk transfer, metode PENERIMA biasanya muncul setelah label "Ke/Tujuan".
// Ambil metode dari bagian "Ke ..." bila ada, karena itulah kanal yang menerima dana.
function detectMethod(lines) {
  const iKe = lines.findIndex((l) => /^(ke|tujuan|penerima|to)\b/i.test(l));
  const zones = iKe >= 0 ? [lines.slice(iKe, iKe + 3).join(' '), lines.join(' ')] : [lines.join(' ')];
  for (const zone of zones) {
    for (const [name, re] of METHODS) if (re.test(zone)) return name;
  }
  return null;
}

// ---- Label umum ----
const LABELS = {
  pengirim: /^(dari|pengirim|nama\s+pengirim|sumber\s+dana|rekening\s+sumber|from|sender)\b/i,
  jumlah: [
    /jumlah\s+total|total\s+(bayar|pembayaran|transfer)|grand\s+total/i,
    /^total\b/i,
    /jumlah\s+transfer|nominal(\s+transfer)?|^jumlah\b|^amount\b/i,
  ],
  transaksi: /(no\.?|nomor|id|kode)\s*(transaksi|referensi|ref\.?|reference|trx)|reference\s*(no|number|id)|transaction\s*id|ref\s*no/i,
  tanggal: /^(tanggal|tgl|waktu|date|time|tanggal\s+transaksi|waktu\s+transaksi)\b/i,
  biaya: /biaya\s*(transfer|admin|layanan|transaksi)?|admin\s*fee|\bfee\b/i,
};

// "GRATIS"/"Free" → 0, "Rp 2.500" → 2500
const parseFee = (s) => (/gratis|free|bebas/i.test(s) ? 0 : parseAmount(s));

const BULAN = {
  jan: 1, januari: 1, january: 1, feb: 2, februari: 2, february: 2, mar: 3, maret: 3, march: 3,
  apr: 4, april: 4, mei: 5, may: 5, jun: 6, juni: 6, june: 6, jul: 7, juli: 7, july: 7,
  agu: 8, agt: 8, ags: 8, agustus: 8, aug: 8, august: 8, sep: 9, sept: 9, september: 9,
  okt: 10, oktober: 10, oct: 10, october: 10, nov: 11, nopember: 11, november: 11,
  des: 12, desember: 12, dec: 12, december: 12,
};

const iso = (y, m, d) => {
  const dt = new Date(Date.UTC(y, m - 1, d));
  if (isNaN(dt) || dt.getUTCMonth() !== m - 1 || y < 2000) return null;
  return `${y}-${String(m).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
};

function parseDate(s) {
  let m = s.match(/(\d{1,2})\s+([A-Za-z]{3,9})\.?\s+(\d{4})/);
  if (m && BULAN[m[2].toLowerCase()]) return iso(+m[3], BULAN[m[2].toLowerCase()], +m[1]);
  m = s.match(/(\d{1,2})[\/\-.](\d{1,2})[\/\-.](\d{4})/);
  if (m) return iso(+m[3], +m[2], +m[1]);
  m = s.match(/(\d{4})[\/\-.](\d{1,2})[\/\-.](\d{1,2})/);
  if (m) return iso(+m[1], +m[2], +m[3]);
  return null;
}

function parseTime(s) {
  const m = s.match(/\b([01]?\d|2[0-3])[:.]([0-5]\d)(?:[:.][0-5]\d)?\s*(WIB|WITA|WIT)?\b/);
  return m ? `${m[1].padStart(2, '0')}.${m[2]}${m[3] ? ' ' + m[3] : ''}` : null;
}

// "Rp 33.000", "Rp33.000,00", "IDR 33,000.00" → 33000
function parseAmount(s) {
  const m = s.match(/(?:rp|idr)\.?\s*([\d][\d.,]*)/i);
  if (!m) return null;
  let v = m[1].replace(/[.,]\d{2}$/, ''); // buang sen
  v = v.replace(/[.,]/g, '');
  return v ? Number(v) : null;
}

const NOISE = /^[^A-Za-z0-9]*$/;

// Ambil nilai untuk label: sisa baris itu sendiri, atau baris-baris berikutnya.
function valueAfter(lines, labelRe, accept, lookahead = 2) {
  for (let i = 0; i < lines.length; i++) {
    const hit = lines[i].match(labelRe);
    if (!hit) continue;
    const rest = lines[i].slice(hit.index + hit[0].length).replace(/^[\s:~\-=|]+/, '');
    const same = rest && accept(rest);
    if (same) return { value: same, line: i };
    for (let k = i + 1; k <= i + lookahead && k < lines.length; k++) {
      if (NOISE.test(lines[k])) continue;
      const v = accept(lines[k]);
      if (v) return { value: v, line: k };
    }
  }
  return null;
}

const cleanName = (s) => {
  const n = s.replace(/^[^A-Za-z]+/, '').replace(/\s+(seabank|bca|bri|bni|mandiri|dana|ovo|gopay)\b.*$/i, '').trim();
  return /[A-Za-z]{2,}/.test(n) && !/\d{6,}/.test(n) ? n : null;
};

function parseReceipt(text) {
  const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);

  const pengirim = valueAfter(lines, LABELS.pengirim, cleanName)?.value ?? null;

  let jumlah = null;
  for (const re of LABELS.jumlah) {
    jumlah = valueAfter(lines, re, parseAmount)?.value ?? null;
    if (jumlah) break;
  }
  if (!jumlah) {
    const amounts = lines.map(parseAmount).filter(Boolean);
    if (amounts.length) jumlah = Math.max(...amounts);
  }

  // No. transaksi: alfanumerik ≥ 6, dan sambung digit yang terpotong ke baris berikutnya
  let transaksi = null;
  const tx = valueAfter(lines, LABELS.transaksi, (s) => (s.match(/\b([A-Z0-9]{6,})\b/i) || [])[1] || null);
  if (tx) {
    transaksi = tx.value;
    for (let k = tx.line + 1; k <= tx.line + 3 && k < lines.length; k++) {
      if (/^\d{1,10}$/.test(lines[k])) transaksi += lines[k];
      else if (/[a-z]{3,}/i.test(lines[k])) break;
    }
  }

  // Tanggal & jam: label dulu, lalu pola di mana saja, lalu prefix YYYYMMDD no. transaksi
  let tanggal = valueAfter(lines, LABELS.tanggal, parseDate)?.value ?? null;
  if (!tanggal) for (const l of lines) if ((tanggal = parseDate(l))) break;
  if (!tanggal && transaksi) {
    const m = transaksi.match(/^(20\d{2})(\d{2})(\d{2})/);
    if (m) tanggal = iso(+m[1], +m[2], +m[3]);
  }
  let jam = valueAfter(lines, LABELS.tanggal, parseTime)?.value ?? null;
  if (!jam) {
    const dateLine = lines.find((l) => parseDate(l) && parseTime(l));
    if (dateLine) jam = parseTime(dateLine);
  }

  // Biaya transfer/admin (null = tidak tercantum di bukti)
  const fee = valueAfter(lines, LABELS.biaya, (s) => { const v = parseFee(s); return v === null ? null : { v }; });
  const biaya = fee ? fee.value.v : null;

  const sukses = lines.some((l) => /berhasil|sukses|diterima|success(ful)?|completed/i.test(l));

  return { metode: detectMethod(lines), pengirim, jumlah, biaya, transaksi, tanggal, jam, sukses };
}

async function extractFromReceipt(imagePath) {
  const text = await readText(imagePath);
  return { ...parseReceipt(text), rawText: text };
}

module.exports = { extractFromReceipt, parseReceipt };
