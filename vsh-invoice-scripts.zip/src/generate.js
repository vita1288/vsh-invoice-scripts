#!/usr/bin/env node
// Bukti transfer (screenshot) → OCR → konfirmasi → invoice PDF + PNG via Playwright.
//
//   node src/generate.js --bukti bukti.jpg --produk canva-pro-6
//   node src/generate.js --bukti bukti.jpg --produk canva-pro-6 --nama "Jazid" --yes
//   node src/generate.js --produk canva-pro-6 --nama "Jazid" --metode BCA --jumlah 33000 --biaya 0 --transaksi ABC123 --tanggal 2026-10-07
const fs = require('fs');
const path = require('path');
const readline = require('readline/promises');
const { chromium } = require('playwright');
const { extractFromReceipt } = require('./receipt');

const ROOT = path.join(__dirname, '..');
const read = (p) => JSON.parse(fs.readFileSync(path.join(ROOT, p), 'utf8'));

// ---------- argumen ----------
function parseArgs(argv) {
  const a = {};
  for (let i = 0; i < argv.length; i++) {
    const k = argv[i];
    if (!k.startsWith('--')) continue;
    const key = k.slice(2);
    const next = argv[i + 1];
    if (next === undefined || next.startsWith('--')) a[key] = true;
    else { a[key] = next; i++; }
  }
  return a;
}

// ---------- format ----------
const toNum = (s) => Number(String(s).replace(/[^\d]/g, '')) || 0;
const rupiah = (n) => 'Rp ' + Number(n).toLocaleString('id-ID');
const fmtDate = (isoStr, month = 'long') =>
  new Date(isoStr + 'T00:00:00Z').toLocaleDateString('id-ID', { day: 'numeric', month, year: 'numeric', timeZone: 'UTC' });
const addMonths = (isoStr, n) => {
  const d = new Date(isoStr + 'T00:00:00Z'); // UTC: hindari geser hari karena zona waktu
  const day = d.getUTCDate();
  d.setUTCMonth(d.getUTCMonth() + n);
  if (d.getUTCDate() < day) d.setUTCDate(0); // 31 Jan + 1 bln → 28/29 Feb
  return d.toISOString().slice(0, 10);
};
const todayISO = () => {
  const d = new Date();
  return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
};

// ---------- penomoran & arsip ----------
const DATA = path.join(ROOT, 'data');
const LEDGER = path.join(DATA, 'invoices.json');
const loadLedger = () => (fs.existsSync(LEDGER) ? JSON.parse(fs.readFileSync(LEDGER, 'utf8')) : []);

function nextInvoiceNo(prefix, isoDate, ledger) {
  const ymd = isoDate.replace(/-/g, '');
  const n = ledger.filter((r) => r.noInvoice.startsWith(`${prefix}/${ymd}/`)).length + 1;
  return `${prefix}/${ymd}/${String(n).padStart(3, '0')}`;
}

// ---------- konfirmasi interaktif ----------
async function confirm(data, fields) {
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });
  console.log('\nPeriksa data (Enter = pakai nilai di [kurung], ketik untuk mengganti):');
  for (const [key, label] of fields) {
    const cur = data[key] ?? '';
    const ans = (await rl.question(`  ${label} [${cur}]: `)).trim();
    if (ans) data[key] = ['jumlah', 'biaya'].includes(key) ? toNum(ans) : ans;
  }
  const ok = (await rl.question('Buat invoice? (Y/n): ')).trim().toLowerCase();
  rl.close();
  return ok === '' || ok === 'y';
}

// ---------- render ----------
function fill(tpl, vars) {
  const esc = (s) => String(s).replace(/[&<>"]/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]));
  return tpl.replace(/\{\{(\w+)\}\}/g, (_, k) => (k === 'logo' ? vars[k] : esc(vars[k] ?? '')));
}

async function render(html, outBase) {
  const browser = await chromium.launch(process.env.CHROME_PATH ? { executablePath: process.env.CHROME_PATH } : {});
  try {
    const page = await browser.newPage({ viewport: { width: 794, height: 1123 }, deviceScaleFactor: 2 });
    await page.setContent(html, { waitUntil: 'load' });
    await page.waitForLoadState('networkidle', { timeout: 5000 }).catch(() => {}); // font Google (opsional)
    await page.evaluate(() => document.fonts.ready);
    await page.pdf({ path: outBase + '.pdf', format: 'A4', printBackground: true, margin: { top: 0, right: 0, bottom: 0, left: 0 } });
    await page.locator('.page').screenshot({ path: outBase + '.png' });
  } finally {
    await browser.close();
  }
}

// ---------- main ----------
async function main() {
  const args = parseArgs(process.argv.slice(2));
  if (args.help || !args.produk) {
    console.log(fs.readFileSync(__filename, 'utf8').split('\n').slice(1, 6).join('\n').replace(/^\/\/ ?/gm, ''));
    process.exit(args.help ? 0 : 1);
  }

  const store = read('config/store.json');
  const products = read('config/products.json');
  const produk = products[args.produk];
  if (!produk) throw new Error(`Produk "${args.produk}" tidak ada di config/products.json. Tersedia: ${Object.keys(products).join(', ')}`);

  // 1) Data dari bukti transfer (OCR), lalu override dari argumen
  let data = { metode: null, pengirim: null, jumlah: null, biaya: null, transaksi: null, tanggal: null, jam: null };
  if (args.bukti) {
    console.log(`Membaca bukti transfer: ${args.bukti} ...`);
    const ocr = await extractFromReceipt(path.resolve(args.bukti));
    if (args.debug) console.log('--- OCR ---\n' + ocr.rawText + '\n-----------');
    data = { ...data, ...ocr };
    if (!ocr.sukses) console.warn('! Kata "berhasil/diterima" tidak ditemukan di bukti. Pastikan transfer sukses.');
  }
  const map = { nama: 'pelanggan', metode: 'metode', jumlah: 'jumlah', biaya: 'biaya', transaksi: 'transaksi', tanggal: 'tanggal', jam: 'jam' };
  const NUMERIC = ['jumlah', 'biaya'];
  for (const [arg, key] of Object.entries(map)) if (typeof args[arg] === 'string') data[key] = NUMERIC.includes(arg) ? toNum(args[arg]) : args[arg];
  data.pelanggan = data.pelanggan || data.pengirim;
  data.tanggal = data.tanggal || todayISO();
  data.biaya = data.biaya ?? 0; // tidak tercantum di bukti → 0
  data.jumlah = data.jumlah ?? produk.harga + data.biaya;
  data.qty = Number(args.qty || 1);

  // 2) Konfirmasi
  if (!args.yes) {
    const ok = await confirm(data, [
      ['pelanggan', 'Nama pelanggan'],
      ['metode', 'Metode pembayaran'],
      ['jumlah', 'Jumlah dibayar (total)'],
      ['biaya', 'Biaya transfer/admin'],
      ['transaksi', 'No. transaksi/ref'],
      ['tanggal', 'Tanggal bayar (YYYY-MM-DD)'],
      ['jam', 'Jam bayar (opsional)'],
    ]);
    if (!ok) return console.log('Dibatalkan.');
  }
  for (const k of ['pelanggan', 'metode']) if (!data[k]) throw new Error(`"${k}" kosong. Isi saat konfirmasi atau lewat --${k === 'pelanggan' ? 'nama' : k}.`);

  const subtotal = produk.harga * data.qty;
  const total = subtotal + data.biaya;
  const lunas = data.jumlah >= total;
  if (!lunas) console.warn(`! Dibayar ${rupiah(data.jumlah)} < total ${rupiah(total)} → status BELUM LUNAS.`);

  // 3) Duplikat no. transaksi → pakai nomor invoice lama
  const ledger = loadLedger();
  const dup = data.transaksi && ledger.find((r) => r.transaksi === data.transaksi);
  const noInvoice = dup ? dup.noInvoice : nextInvoiceNo(store.prefixInvoice, data.tanggal, ledger);
  if (dup) console.warn(`! No. transaksi sudah pernah dipakai di ${dup.noInvoice}; invoice dibuat ulang dengan nomor yang sama.`);

  // 4) Render
  const logoPath = path.join(ROOT, store.logo);
  const logoMime = /\.png$/i.test(logoPath) ? 'image/png' : 'image/jpeg';
  const vars = {
    logo: `data:${logoMime};base64,${fs.readFileSync(logoPath).toString('base64')}`,
    tokoNama: store.nama, tokoTagline: store.tagline, tokoInstagram: store.instagram,
    noInvoice, pelanggan: data.pelanggan,
    tanggalInvoice: fmtDate(data.tanggal),
    status: lunas ? 'LUNAS' : 'BELUM LUNAS', statusClass: lunas ? 'lunas' : 'belum',
    produkNama: produk.nama, produkDeskripsi: produk.deskripsi,
    periode: `${fmtDate(data.tanggal, 'short')} – ${fmtDate(addMonths(data.tanggal, produk.bulan * data.qty), 'short')}`,
    durasi: `${produk.bulan} bulan`, qty: data.qty,
    subtotal: rupiah(subtotal), biaya: data.biaya ? rupiah(data.biaya) : 'Gratis', total: rupiah(total),
    metode: data.metode,
    tanggalBayar: fmtDate(data.tanggal) + (data.jam ? `, ${data.jam}` : ''),
    transaksi: data.transaksi || '-',
    jumlahDiterima: rupiah(data.jumlah),
  };
  const html = fill(fs.readFileSync(path.join(ROOT, 'template/invoice.html'), 'utf8'), vars);

  const outDir = path.resolve(args.out || path.join(ROOT, 'output'));
  fs.mkdirSync(outDir, { recursive: true });
  const outBase = path.join(outDir, noInvoice.replace(/\//g, '-'));
  await render(html, outBase);

  // 5) Arsip
  if (!dup) {
    fs.mkdirSync(DATA, { recursive: true });
    ledger.push({ noInvoice, dibuat: new Date().toISOString(), pelanggan: data.pelanggan, produk: args.produk, subtotal, total, ...pick(data, ['metode', 'jumlah', 'biaya', 'transaksi', 'tanggal']) });
    fs.writeFileSync(LEDGER, JSON.stringify(ledger, null, 2));
  }

  console.log(`\n✓ ${noInvoice}\n  ${outBase}.pdf\n  ${outBase}.png`);
}

const pick = (o, ks) => Object.fromEntries(ks.map((k) => [k, o[k]]));

main().catch((e) => { console.error('Error:', e.message); process.exit(1); });
